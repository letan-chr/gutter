export const DEFAULT_LANGUAGE = "en";
